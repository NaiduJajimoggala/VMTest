//
//  PeopleTableViewCell.swift
//  VM
//
//  Created by Swami Naidu on 22/06/21.
//  Copyright © 2021 Accenture. All rights reserved.
//

import UIKit

class PeopleTableViewCell: UITableViewCell {
    
    // MARK: - IBOutlets
    
    @IBOutlet weak var pImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var jobTitle: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
