//
//  ViewController.swift
//  VM
//
//  Created by Swami Naidu on 21/06/21.
//  Copyright © 2021 Accenture. All rights reserved.
//

import UIKit

class PeoplesViewController: UITableViewController {
    
    var peopleList: People = []
    
    private var peopleViewModel : PeopleViewModel!
    private var dataSource : PeopleTableViewDataSource<PeopleTableViewCell,Person>!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView()
       // tableView.allowsSelection = false
       // tableView.allowsSelectionDuringEditing = false 
        
        self.navigationController?.navigationBar.barTintColor = Utility.hexStringToUIColor(hex: "#C40202")
        //self.navigationController?.navigationBar.topItem?.title = "People Details"
        
        // Do any additional setup after loading the view.
        let URLStr =  APIList.peopleApi
        if NetworkCheck.isConnectedToNetwork(){
            let activityIndicator:UIActivityIndicatorView = UIActivityIndicatorView()
            activityIndicator.center = self.view.center
            activityIndicator.hidesWhenStopped = true
            activityIndicator.color = Utility.hexStringToUIColor(hex: "#C40202")
            view.addSubview(activityIndicator)
            activityIndicator.startAnimating()
            
            
            callToViewModelForUIUpdate()
            
            ApiManager().RequestGetServiceWithDecodeClass(apiName: URLStr) { (objPeople:People) in
                if objPeople.count > 0{
                    self.peopleList = objPeople
                }
                
                self.tableView?.reloadData()
                activityIndicator.stopAnimating()
                
            }
            
        }else{
            let secondsToDelay = 1.0
            perform(#selector(showInternetAlert), with: nil, afterDelay: secondsToDelay)
            
        }
        
    }
    
    func callToViewModelForUIUpdate(){
        
        self.peopleViewModel =  PeopleViewModel()
        self.peopleViewModel.bindPeopleViewModelToController = {
            self.updateDataSource()
        }
    }
    
    func updateDataSource(){
        
        self.dataSource = PeopleTableViewDataSource(cellIdentifier: "PeopleTableViewCell", items: self.peopleViewModel.peopleData!, configureCell: { (cell, objPerson) in
            cell.nameLabel.text = objPerson.firstName
            cell.nameLabel.textColor = Utility.hexStringToUIColor(hex: "#C40202")
            cell.phoneNumberLabel.text = objPerson.phone
            cell.jobTitle.text = objPerson.jobTitle
            cell.emailLabel.text = objPerson.email
            
            cell.pImage.layer.cornerRadius = cell.pImage.frame.width/2
            cell.imageView?.layer.borderWidth = 1.0;
            cell.imageView?.layer.borderColor = UIColor.blue.cgColor
            cell.imageView?.clipsToBounds = true
            cell.pImage.image = UIImage(named: "ImageMissing")
            
            if let url = URL(string: objPerson.avatar ?? "") {
                let task = URLSession.shared.dataTask(with: url) { data, response, error in
                    guard let data = data, error == nil else { return }
                    
                    DispatchQueue.main.async { 
                        cell.pImage.image = UIImage(data: data)
                    }
                }
                
                task.resume()
            }
        })
        
        
        DispatchQueue.main.async {
            self.tableView.dataSource = self.dataSource
            self.tableView.reloadData()
        }
    }
    
    
    @objc func showInternetAlert(){
        
        let alert = UIAlertController(title: "No Internet Detected", message: "This app requires an Internet connection", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
//    // MARK: - Table view data source
//
//    override func numberOfSections(in tableView: UITableView) -> Int {
//        // #warning Incomplete implementation, return the number of sections
//        return 1
//    }
//
//    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        // #warning Incomplete implementation, return the number of rows
//        // print("checking.....",self.peopleList)
//        return self.peopleList.count
//    }
//    
//
//    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "PeopleTableViewCell", for: indexPath) as! PeopleTableViewCell
//        cell.person = self.peopleList[indexPath.row]
//        return cell
//    }
//
//
//
//    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
//        return 100.0;//Choose your custom row height
//    }
}

