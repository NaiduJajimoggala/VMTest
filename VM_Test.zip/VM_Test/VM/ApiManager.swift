//
//  ApiManager.swift
//  VM
//
//  Created by Swami Naidu on 21/06/21.
//  Copyright © 2021 Accenture. All rights reserved.
//

import Foundation


class ApiManager: NSObject {
    
    
    //get request model
    func RequestGetServiceWithDecodeClass<T:Codable>(apiName:(String), completion:@escaping (T)->Void){
            let session = URLSession.shared
            // Setup the request with URL
            let url = URL(string: apiName)
            let task = session.dataTask(with: url!) { data, response, error in
                DispatchQueue.main.async {
                    do {
                        // make sure this JSON is in the format we expect
                        if let json = try JSONSerialization.jsonObject(with: data!, options: []) as? [String: Any] {
        
                            print(json)
                        }
                        
                        let GenericObj: T = try JSONDecoder().decode(T.self, from: data ?? Data())
                        completion(GenericObj)
                    } catch let error as NSError {
                        print("Failed to load: \(error.localizedDescription)")
                    }
                }
                
            }
            task.resume()
    }
}
