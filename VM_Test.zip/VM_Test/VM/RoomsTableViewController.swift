import UIKit

class RoomsTableViewController: UITableViewController {
    
    var roomsList: Rooms = []
    
    private var roomsViewModel : RoomsViewModel!
    private var dataSource : RoomsTableViewDataSource<RoomCell,Room>!
    private var activityIndicator:UIActivityIndicatorView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = UIView()
        tableView.allowsSelection = false
        // Do any additional setup after loading the view.
       // self.navigationController?.navigationBar.topItem?.title = "Rooms Details"
        if NetworkCheck.isConnectedToNetwork(){
            activityIndicator = UIActivityIndicatorView()
            activityIndicator?.center = self.view.center
            activityIndicator?.hidesWhenStopped = true
            activityIndicator?.color = Utility.hexStringToUIColor(hex: "#C40202")
            view.addSubview(activityIndicator!)
            activityIndicator?.startAnimating()
            
            //call view model for data update
            callToViewModelForUIUpdate()
                        
        }else{
            showInternetAlert()
        }
        
    }
    
    func callToViewModelForUIUpdate(){
        
        self.roomsViewModel =  RoomsViewModel()
        self.roomsViewModel.bindRoomsViewModelToController = {
            self.updateDataSource()
            self.activityIndicator?.stopAnimating()
        }
    }
    
    func updateDataSource(){
        self.dataSource = RoomsTableViewDataSource(cellIdentifier: "RoomCell", items: self.roomsViewModel.roomsData!, configureCell: { (cell, objroom) in
            cell.nameLabel.text = objroom.name
            cell.nameLabel.textColor = Utility.hexStringToUIColor(hex: "#C40202")
            cell.idLabel.text = objroom.id
            cell.maxOccupancyLabel.text = "\(String(describing: objroom.maxOccupancy ?? 0 ))"
            cell.createdAtLabel.text = objroom.createdAt
        })
        
        DispatchQueue.main.async {
            self.tableView.dataSource = self.dataSource
            self.tableView.reloadData()
        }
    }
    
    func showInternetAlert(){
        let alert = UIAlertController(title: "No Internet Detected", message: "This app requires an Internet connection", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
}
