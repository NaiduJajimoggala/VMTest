//
//  MasterTableViewController.swift
//  VM
//
//  Created by a.naidu.jajimoggala on 11/08/21.
//  Copyright © 2021 Accenture. All rights reserved.
//

/**
 *
 */

import UIKit

class MasterTableViewControlle: UITableViewController {
    var mainMenu = ["People", "Rooms"]
    var mainMenuImages = ["people.png","Room.jpeg"];
    override func viewDidLoad() {
        super.viewDidLoad()
        //self.delegate = self
        tableView.tableFooterView = UIView()
        self.tableView.separatorInset = UIEdgeInsets.zero;
        self.navigationController?.navigationBar.topItem?.title = "DashBoard"
        self.navigationController?.navigationBar.barTintColor = Utility.hexStringToUIColor(hex: "#C40202")
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        self.splitViewController?.preferredDisplayMode = UISplitViewController.DisplayMode.primaryOverlay
    }
    
    func splitViewController(_ splitViewController: UISplitViewController, collapseSecondary secondaryViewController: UIViewController, onto primaryViewController: UIViewController) -> Bool {
        return true
    }
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return mainMenu.count
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mainCell", for: indexPath)
        cell.imageView?.image = UIImage(named:mainMenuImages[indexPath.row])
        cell.textLabel?.text = mainMenu[indexPath.row]
        
        
        // Configure the cell...
        
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        
        if indexPath.row == 0{
            let controller = storyboard?.instantiateViewController(identifier: "PeopleVC") as! PeoplesViewController;
            self.splitViewController?.showDetailViewController(controller, sender: nil)
            //performSegue(withIdentifier: "people", sender: self)
        }
        else if indexPath.row == 1{
            let controller = storyboard?.instantiateViewController(identifier: "RoomsVC") as! RoomsTableViewController;
            self.splitViewController?.showDetailViewController(controller, sender: nil)
            
        }
       // let cell = tableView.cellForRow(at: indexPath)
        
       // cell?.textLabel?.textColor = Utility.hexStringToUIColor(hex: "#C40202")
    
    }
    
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "people" {
           
                let controller = segue.destination as! PeoplesViewController
          //  self.modalPresentationStyle = .fullScreen
            self.splitViewController?.showDetailViewController(controller, sender: nil)
           
        }else if segue.identifier == "rooms"{
            let controller = segue.destination as! RoomsTableViewController
           // self.modalPresentationStyle = .fullScreen
            self.splitViewController?.showDetailViewController(controller, sender: nil)
            //self.navigationController?.pushViewController(controller, animated: true)
           // self.navigationController?.present(controller, animated: true, completion: nil)
           // self.present(controller, animated: true, completion: nil)
        }
    }
    
//    func prepareforsegue(segue: UIStoryboardSegue, sender: AnyObject?){
//
//        if (segue.identifier == "people") {
//            // initialize new view controller and cast it as your view controller
//            let viewController = segue.destination as! PeoplesViewController
//            self.navigationController?.pushViewController(viewController, animated: true)
//
//        }else{
//            let viewController = segue.destination as! RoomsTableViewController
//            self.navigationController?.pushViewController(viewController, animated: true)
//        }
//    }
   
}
