//
//  PeopleViewModel.swift
//  VM
//
//Created by a.naidu.jajimoggala on 11/08/21.
//  Copyright © 2021 Accenture. All rights reserved.
//

import Foundation

class PeopleViewModel : NSObject {
    
    private var apiManager : ApiManager!
    private(set) var peopleData : People? {
        didSet {
            self.bindPeopleViewModelToController()
        }
    }
    
    var bindPeopleViewModelToController : (() -> ()) = {}
    
    override init() {
        super.init()
        self.apiManager =  ApiManager()
        callFuncToGetEmpData()
    }
    
    func callFuncToGetEmpData() {
        self.apiManager.RequestGetServiceWithDecodeClass(apiName: APIList.peopleApi) { (objPeople:People) in
            self.peopleData = objPeople
        }
    }
}

