//
//  RoomsViewModel.swift
//  VM
//
//  Created by a.naidu.jajimoggala on 11/08/21.
//  Copyright © 2021 Accenture. All rights reserved.
//

import Foundation

class RoomsViewModel : NSObject {
    
    private var apiManager : ApiManager!
    private(set) var roomsData : Rooms? {
        didSet {
            self.bindRoomsViewModelToController()
        }
    }
    
    var bindRoomsViewModelToController : (() -> ()) = {}
    
    override init() {
        super.init()
        self.apiManager =  ApiManager()
        callFuncToGetRoomData()
    }
    
    func callFuncToGetRoomData() {
        self.apiManager.RequestGetServiceWithDecodeClass(apiName: APIList.roomsApi) { (objRooms:Rooms) in
            self.roomsData = objRooms
        }
    }
}
